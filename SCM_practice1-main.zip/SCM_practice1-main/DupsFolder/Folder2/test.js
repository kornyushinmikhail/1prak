// comment fsdkfllf
var a = 10;
alert(a);
