#include <stdio.h>
int main() {
   printf("Hello, World!\n");
   pointer->abcd;
   m83 = "Midnight city\n";
   return 0;
}
